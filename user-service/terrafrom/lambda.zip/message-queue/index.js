// import axios from 'axios'
// import { product_service_url } from '../config/config'
// export const PullData = async (requestData: Record<string, unknown>) => {
//   return axios.post(product_service_url, requestData)
// }
//# sourceMappingURL=index.js.map