"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResetPassword = exports.Login = exports.SignUp = void 0;
const userRepository_1 = require("../repository/userRepository");
const userService_1 = require("../services/userService");
const core_1 = __importDefault(require("@middy/core"));
const http_json_body_parser_1 = __importDefault(require("@middy/http-json-body-parser"));
const service = new userService_1.UserService(new userRepository_1.UserRepository());
exports.SignUp = (0, core_1.default)((event) => {
    return service.CreateUser(event);
}).use((0, http_json_body_parser_1.default)());
exports.Login = (0, core_1.default)((event) => {
    return service.LoginUser(event);
}).use((0, http_json_body_parser_1.default)());
exports.ResetPassword = (0, core_1.default)((event) => {
    return service.ResetPassword(event);
}).use((0, http_json_body_parser_1.default)());
// export const CreateProfile = middy((event: APIGatewayProxyEventV2) => {
//   return service.CreateProfile(event);
// }).use(bodyParser());
// export const EditProfile = middy((event: APIGatewayProxyEventV2) => {
//   return service.EditProfile(event);
// }).use(bodyParser());
// export const GetProfile = middy((event: APIGatewayProxyEventV2) => {
//   return service.GetProfile(event);
// }).use(bodyParser());
//# sourceMappingURL=userHandler.js.map