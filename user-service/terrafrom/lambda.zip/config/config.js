"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.product_service_url = exports.tWIlioNumber = exports.authToken = exports.accountSid = void 0;
exports.accountSid = 'AC68531e30f1466e789ad0e5a1a36a4add';
exports.authToken = 'a86476ab564e4e2c765b5f387742fe05';
exports.tWIlioNumber = '+17069039215';
exports.product_service_url = "http://127.0.0.1:3000/products-queue"; // here put the url from the api gateway/stages/prod
//# sourceMappingURL=config.js.map